import os
import sys
import logging
from datetime import datetime, date, time, timedelta, timezone
from zoneinfo import ZoneInfo
import requests

# ============================================================
# FOREX TIME BOT V2
# Professional Telegram session-alert bot
# ============================================================

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
CHANNEL_ID = os.getenv("TELEGRAM_CHANNEL_ID", "").strip()

# Branding
CHANNEL_NAME = os.getenv("CHANNEL_NAME", "FOREX DESK GH")
FOOTER = os.getenv(
    "CHANNEL_FOOTER",
    "⚠️ Educational market timing only • Manage risk responsibly."
)

GHANA_TZ = ZoneInfo("Africa/Accra")

SESSIONS = {
    "Sydney": {
        "tz": "Australia/Sydney",
        "open": time(8, 0),
        "close": time(17, 0),
        "flag": "🇦🇺",
        "pairs": "AUD/USD • NZD/USD • AUD/JPY",
    },
    "Tokyo": {
        "tz": "Asia/Tokyo",
        "open": time(9, 0),
        "close": time(18, 0),
        "flag": "🇯🇵",
        "pairs": "USD/JPY • EUR/JPY • GBP/JPY",
    },
    "London": {
        "tz": "Europe/London",
        "open": time(8, 0),
        "close": time(17, 0),
        "flag": "🇬🇧",
        "pairs": "EUR/USD • GBP/USD • EUR/GBP",
    },
    "New York": {
        "tz": "America/New_York",
        "open": time(8, 0),
        "close": time(17, 0),
        "flag": "🇺🇸",
        "pairs": "EUR/USD • GBP/USD • USD/JPY • XAU/USD",
    },
}

# Feature switches
POST_DAILY_BRIEFING = True
POST_OPEN_ALERTS = True
POST_CLOSE_ALERTS = True
POST_OVERLAP_ALERTS = True

# Daily briefing time in Ghana time.
DAILY_BRIEFING_TIME = time(7, 0)

# Overlap is calculated from London/New York local session hours.
OVERLAP_NAME = "London–New York Overlap"

API_URL = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"


def validate_config():
    missing = []
    if not BOT_TOKEN:
        missing.append("TELEGRAM_BOT_TOKEN")
    if not CHANNEL_ID:
        missing.append("TELEGRAM_CHANNEL_ID")
    if missing:
        raise RuntimeError("Missing environment variables: " + ", ".join(missing))


def now_utc():
    return datetime.now(timezone.utc)


def ghana(dt):
    return dt.astimezone(GHANA_TZ)


def ghana_time(dt):
    return ghana(dt).strftime("%I:%M %p").lstrip("0")


def ghana_date(dt):
    return ghana(dt).strftime("%A, %d %B %Y")


def send_message(text):
    response = requests.post(
        API_URL,
        json={
            "chat_id": CHANNEL_ID,
            "text": text,
            "disable_web_page_preview": True,
        },
        timeout=20,
    )
    response.raise_for_status()
    data = response.json()
    if not data.get("ok"):
        raise RuntimeError(f"Telegram API error: {data}")
    return data


def local_dt(day, tz_name, clock):
    return datetime.combine(day, clock, tzinfo=ZoneInfo(tz_name))


def session_times_for_day(name, day):
    s = SESSIONS[name]
    return (
        local_dt(day, s["tz"], s["open"]),
        local_dt(day, s["tz"], s["close"]),
    )


def active_sessions(now):
    active = []
    for name in SESSIONS:
        open_dt, close_dt = session_times_for_day(
            name, now.astimezone(ZoneInfo(SESSIONS[name]["tz"])).date()
        )
        if open_dt <= now < close_dt:
            active.append(name)
    return active


def daily_briefing(now):
    d = now.astimezone(GHANA_TZ).date()

    lines = [
        f"╔══════════════════════════╗",
        f"     📊 {CHANNEL_NAME}",
        f"     DAILY FOREX BRIEFING",
        f"╚══════════════════════════╝",
        "",
        f"📅 {d.strftime('%A, %d %B %Y')}",
        f"🇬🇭 Ghana Time: {ghana_time(now)}",
        "",
        "🕐 SESSION BOARD",
        "──────────────────────────",
    ]

    for name, s in SESSIONS.items():
        # Use the local date corresponding to Ghana's current date as a
        # convenient display day. DST is handled by ZoneInfo.
        open_dt = local_dt(d, s["tz"], s["open"])
        close_dt = local_dt(d, s["tz"], s["close"])

        lines.append(
            f"{s['flag']} {name:<8} "
            f"{ghana_time(open_dt)} — {ghana_time(close_dt)}"
        )

    lines += [
        "",
        "🔥 KEY LIQUIDITY WINDOW",
        f"🇬🇧 London × 🇺🇸 New York",
        f"   {overlap_ghana_window(d)} Ghana time",
        "",
        "📌 PAIRS TO KEEP ON WATCHLIST",
        "EUR/USD • GBP/USD • USD/JPY",
        "XAU/USD • GBP/JPY",
        "",
        FOOTER,
    ]
    return "\n".join(lines)


def overlap_utc_for_day(day):
    london = ZoneInfo("Europe/London")
    new_york = ZoneInfo("America/New_York")

    # Session boundaries for each centre on the relevant local dates.
    # London/New York are normally overlapping from NY 08:00 until
    # London 17:00. Taking the intersection makes DST automatic.
    london_day = day
    ny_day = day

    l_open = local_dt(london_day, "Europe/London", SESSIONS["London"]["open"])
    l_close = local_dt(london_day, "Europe/London", SESSIONS["London"]["close"])
    n_open = local_dt(ny_day, "America/New_York", SESSIONS["New York"]["open"])
    n_close = local_dt(ny_day, "America/New_York", SESSIONS["New York"]["close"])

    start = max(l_open, n_open)
    end = min(l_close, n_close)
    return start, end


def overlap_ghana_window(day):
    start, end = overlap_utc_for_day(day)
    return f"{ghana_time(start)} — {ghana_time(end)}"


def overlap_alert(now, opening=True):
    d = now.astimezone(GHANA_TZ).date()
    start, end = overlap_utc_for_day(d)

    if opening:
        return (
            "🔥 LONDON × NEW YORK OVERLAP\n\n"
            "🇬🇧 London Session + 🇺🇸 New York Session\n"
            f"⏰ Ghana Time: {ghana_time(start)} — {ghana_time(end)}\n\n"
            "📈 Major instruments:\n"
            "• EUR/USD\n"
            "• GBP/USD\n"
            "• USD/JPY\n"
            "• XAU/USD\n\n"
            "💡 Two major market centres are active at the same time.\n\n"
            f"{FOOTER}"
        )

    return (
        "🔔 LONDON × NEW YORK OVERLAP ENDED\n\n"
        f"🇬🇭 Ghana Time: {ghana_time(end)}\n"
        "London and New York are no longer in their shared regular session.\n\n"
        f"{FOOTER}"
    )


def session_open_message(name, event_dt):
    s = SESSIONS[name]
    return (
        f"╔══════════════════════════╗\n"
        f"     🟢 {name.upper()} SESSION OPEN\n"
        f"╚══════════════════════════╝\n\n"
        f"{s['flag']} {name} Market Session\n"
        f"🇬🇭 Ghana Time: {ghana_time(event_dt)}\n"
        f"🌍 Local Time: {event_dt.strftime('%I:%M %p').lstrip('0')}\n\n"
        f"📊 WATCHLIST\n"
        f"{s['pairs']}\n\n"
        f"📌 Status: MARKET SESSION ACTIVE\n\n"
        f"{FOOTER}"
    )


def session_close_message(name, event_dt):
    s = SESSIONS[name]
    return (
        f"╔══════════════════════════╗\n"
        f"     🔴 {name.upper()} SESSION CLOSED\n"
        f"╚══════════════════════════╝\n\n"
        f"{s['flag']} {name} Market Session\n"
        f"🇬🇭 Ghana Time: {ghana_time(event_dt)}\n\n"
        f"📊 Main pairs: {s['pairs']}\n"
        f"📌 Status: SESSION CLOSED\n\n"
        f"{FOOTER}"
    )


def event_for_minute(now):
    events = []

    for name, s in SESSIONS.items():
        tz = ZoneInfo(s["tz"])
        local_day = now.astimezone(tz).date()

        for event, clock in (("open", s["open"]), ("close", s["close"])):
            dt = local_dt(local_day, s["tz"], clock)
            if dt <= now < dt + timedelta(minutes=1):
                events.append(("session", name, event, dt))

    # London/NY overlap.
    d = now.astimezone(GHANA_TZ).date()
    start, end = overlap_utc_for_day(d)

    if start <= now < start + timedelta(minutes=1):
        events.append(("overlap", OVERLAP_NAME, "open", start))
    if end <= now < end + timedelta(minutes=1):
        events.append(("overlap", OVERLAP_NAME, "close", end))

    return events


def should_send_daily(now):
    g = now.astimezone(GHANA_TZ)
    return g.hour == DAILY_BRIEFING_TIME.hour and g.minute == DAILY_BRIEFING_TIME.minute


def is_weekend(now):
    return now.astimezone(GHANA_TZ).weekday() >= 5


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
    )

    validate_config()

    now = now_utc().replace(second=0, microsecond=0)
    logging.info("V2 check: %s UTC | %s Ghana", now.isoformat(), ghana_time(now))

    # Saturday/Sunday: don't create regular session alerts.
    # A Friday close can still be posted naturally.
    if POST_DAILY_BRIEFING and should_send_daily(now) and not is_weekend(now):
        send_message(daily_briefing(now))
        logging.info("Daily briefing sent.")

    if is_weekend(now):
        return

    for kind, name, event, event_dt in event_for_minute(now):
        if kind == "session":
            if event == "open" and POST_OPEN_ALERTS:
                send_message(session_open_message(name, event_dt))
                logging.info("%s open sent.", name)

            elif event == "close" and POST_CLOSE_ALERTS:
                send_message(session_close_message(name, event_dt))
                logging.info("%s close sent.", name)

        elif kind == "overlap" and POST_OVERLAP_ALERTS:
            send_message(overlap_alert(now, opening=(event == "open")))
            logging.info("Overlap %s alert sent.", event)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        logging.exception("Bot failed: %s", exc)
        sys.exit(1)
