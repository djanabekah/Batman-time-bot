# FOREX TIME BOT V2

A professional Telegram forex-session timing bot designed to run automatically in the cloud.

## V2 features

- Professional trading-channel formatting
- Daily 07:00 Ghana-time market briefing
- Sydney open/close alerts
- Tokyo open/close alerts
- London open/close alerts
- New York open/close alerts
- London × New York overlap alert
- Overlap-end alert
- Ghana-time display
- DST-aware session calculations using Python `zoneinfo`
- Weekend suppression
- Configurable channel branding
- Render Cron deployment
- Secrets stored as environment variables

## Default Ghana-time schedule

The bot calculates session times dynamically. London, New York and Sydney can shift in Ghana time when their local clocks change because of daylight saving.

Tokyo has no DST.

## Telegram setup

1. Open Telegram and search for `@BotFather`.
2. Send `/newbot`.
3. Follow the instructions.
4. Save the token privately.
5. Add your bot to your Telegram channel as an administrator.
6. Give it permission to post messages.
7. For a public channel, use the channel username as `TELEGRAM_CHANNEL_ID`, e.g. `@MyForexDesk`.

Do not publish your bot token.

## Deploy with Render

Create a GitHub repository and upload:

- `bot.py`
- `requirements.txt`
- `render.yaml`
- `.python-version`
- `.gitignore`

In Render, create the Cron Job from the repository.

The included configuration uses:

Build:
`pip install -r requirements.txt`

Start:
`python bot.py`

Schedule:
`* * * * *`

Environment variables:

`TELEGRAM_BOT_TOKEN`
`TELEGRAM_CHANNEL_ID`
`CHANNEL_NAME`
`CHANNEL_FOOTER`

Render cron schedules are UTC. The bot itself performs all session calculations using the correct financial-centre time zones.

## Branding

Change:

`CHANNEL_NAME=FOREX DESK GH`

to your own channel brand, for example:

`CHANNEL_NAME=ABEKAH FOREX HUB`

You can also change:

`CHANNEL_FOOTER`

## Safety

This bot is a market-session timing tool. It does not make claims about guaranteed profits and does not automatically place trades.

Economic-calendar/news integration is deliberately not enabled in this version because news APIs differ in licensing, rate limits and reliability. It can be added later using a provider/API key you choose.
