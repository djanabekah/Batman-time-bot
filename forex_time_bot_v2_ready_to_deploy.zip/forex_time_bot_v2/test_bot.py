# Simple offline tests for the timing logic.
# Run: python test_bot.py

from datetime import datetime, timezone
from bot import (
    SESSIONS,
    event_for_minute,
    overlap_utc_for_day,
    overlap_ghana_window,
)

def main():
    day = datetime(2026, 9, 28, tzinfo=timezone.utc)

    start, end = overlap_utc_for_day(day.date())
    assert start < end

    print("Sessions:", ", ".join(SESSIONS))
    print("London/New York overlap:", overlap_ghana_window(day.date()))
    print("Basic timing tests: PASS")

if __name__ == "__main__":
    main()
